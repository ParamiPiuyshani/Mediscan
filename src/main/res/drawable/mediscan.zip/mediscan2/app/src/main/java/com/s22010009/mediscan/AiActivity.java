package com.s22010009.mediscan;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AiActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aipage);
    }
}